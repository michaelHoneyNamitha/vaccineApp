package com.example.vaccines;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ActivityScreen2 extends AppCompatActivity {
    //database
    MyDatabase db=null;
    PatientDAO patientDAO=null;
    ArrayList<Patient> patientsList=new ArrayList<>();;
    ListView lv;
    PatientsAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2_vaccines_list);
        //  initialize the db and dao variables
        db = MyDatabase.getDatabase(getApplicationContext());
        patientDAO = db.patientDAO();
        //get the user send from LoginScreen when this screen loads
        Intent intent = getIntent();
        // use the productDAO to get all the database
       patientsList = (ArrayList<Patient>) patientDAO.getEligible();
       adapter  = new PatientsAdapter(this, patientsList);

        lv = findViewById(R.id.lvPatients);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("ABC","item cilicked: "+i);
                Log.d("button","button clicked"+i);
                // send the id of the clicked product to Screen #3
                Patient p= patientsList.get(i);
                Uri phoneNumber = Uri.parse("tel:"+p.phoneNumber );

                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(phoneNumber);

                if (callIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(callIntent);
                }

            }
        });

    }

    public void goBackPressed(View view) {
        // goes back to the previous screen
        finish();
    }

    public void sortPressed(View view) {

        patientsList.clear();

        patientsList.addAll(patientDAO.getAllByPriority());

        adapter.notifyDataSetChanged();


    }

    public void clearListPressed(View view) {
        patientDAO.deleteAll();
        patientsList.clear();
        adapter.notifyDataSetChanged();

    }
}