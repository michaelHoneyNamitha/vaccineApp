package com.example.vaccines;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityMain extends AppCompatActivity {
    //database
    MyDatabase db=null;
    PatientDAO patientDAO=null;
    //EditText
    EditText etName,etAge,etPhoneNumber;
    TextView tvResults;
    String name,phone;
    int age;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //  initialize the db and dao variables
        db = MyDatabase.getDatabase(getApplicationContext());
        patientDAO = db.patientDAO();

    }
    public void signupPressed(View view) {
         etName=findViewById(R.id.etName);
         etAge=findViewById(R.id.etAge);
         etPhoneNumber=findViewById(R.id.etPhoneNumber);
         tvResults=findViewById(R.id.tvResults);

         name = etName.getText().toString();
         age = Integer.parseInt(etAge.getText().toString());
         phone = etPhoneNumber.getText().toString();
         String phoneStartsNum = phone.substring(0, 3);


        if(age>80){
            tvResults.setText("You are eligible for the vaccine!\nYou are priority # 1.");
            etName.setText("");
            etAge.setText("");
            etPhoneNumber.setText("");
            Patient p= new Patient(name,age,phone,true,1);
            patientDAO.insert(p);

        }
        else if(age>65 && age<=80){
            tvResults.setText("You are eligible for the vaccine!\nYou are priority # 2.");
            etName.setText("");
            etAge.setText("");
            etPhoneNumber.setText("");
            patientDAO.insert(new Patient(name,age,phone,true,2));

        }
        else if((age>40 && age<=65) ||(phoneStartsNum.equals("237"))){
            tvResults.setText("You are eligible for the vaccine!\nYou are priority # 3.");
            etName.setText("");
            etAge.setText("");
            etPhoneNumber.setText("");
            patientDAO.insert(new Patient(name,age,phone,true,3));

        }
        else{
            tvResults.setText("Sorry, you are not eligible to receive the vaccine at this time.\n" +
                    "You are not over 40 and you don’t have an eligible phone number.");
            etName.setText("");
            etAge.setText("");
            etPhoneNumber.setText("");
            patientDAO.insert(new Patient(name,age,phone,false,-1));

        }



    }
    public void checkCurrentListPressed(View view) {
        Intent i = new Intent(this, ActivityScreen2.class);
        startActivity(i);
    }
}