package com.example.vaccines;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PatientDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Patient patients);
    //Function to get all patients from the Patients table
    @Query("SELECT * FROM patients ")
    List<Patient> getAll() ;
   //Function to get all patients from the Patients table who are eligible for the vaccine
    @Query("SELECT * FROM patients WHERE isEligible=1")
    List<Patient> getEligible() ;
    //Function to get all patients from the Patients table who are eligible for the vaccine, sorted by priority
    @Query("SELECT * FROM patients WHERE isEligible=1 ORDER BY priorityNumber ASC ")
    List<Patient> getAllByPriority() ;
    //Function to delete all entries in the Patients table
    @Query("DELETE FROM patients")
    void deleteAll();





}
