package com.example.vaccines;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PatientsAdapter extends ArrayAdapter<Patient> {
    public PatientsAdapter(Context context, ArrayList<Patient> patients) {
        super(context, 0, patients);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Patient patient = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_layout, parent, false);
        }
        TextView tvName=(convertView).findViewById(R.id.tvName);
        TextView tvAge=(convertView).findViewById(R.id.tvAge);
        TextView tvPhone=(convertView).findViewById(R.id.tvPhoneNumber);
        TextView tvNo=(convertView).findViewById(R.id.tvPrority);
        tvName.setText(patient.name);
        tvAge.setText(String.valueOf(patient.age));
        tvPhone.setText(patient.phoneNumber);
        tvNo.setText(String.valueOf(patient.priorityNumber));

        return convertView;
    }
}