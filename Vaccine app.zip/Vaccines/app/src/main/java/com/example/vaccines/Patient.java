package com.example.vaccines;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "patients")
public class Patient {
    @PrimaryKey(autoGenerate = true)
    int id;
    String name;
    int age;
    String phoneNumber;
    boolean isEligible;
    int priorityNumber;

    public Patient(String name, int age, String phoneNumber, boolean isEligible, int priorityNumber) {
        this.name = name;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.isEligible = isEligible;
        this.priorityNumber = priorityNumber;
    }
}
